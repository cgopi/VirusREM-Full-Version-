package com.crossover.techtrial.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.crossover.techtrial.model.Comment;

@Repository
@Transactional(readOnly = true)
public class CommentRepositoryImpl implements CommentRepositoryCustom {

	@PersistenceContext
    EntityManager entityManager;
	
	@Override
	public List<Comment> findByArticleIdOrderByDate(Long articleId) {
		Query query = entityManager.createNativeQuery("SELECT c.article.article_id FROM comment c ORDER BY c.date", Comment.class);
		List<Comment> comments = query.getResultList();
        return comments;
	}

}
