package com.crossover.techtrial.repository;

import java.util.List;

import com.crossover.techtrial.model.Article;

public interface ArticleRepositoryCustom {
	 List<Article> findTop10ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(String title,
		      String content);
}
