package com.crossover.techtrial.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.crossover.techtrial.model.Article;

@Repository
@Transactional(readOnly = true)
public class ArticleRepositoryImpl implements ArticleRepositoryCustom {
    
	@PersistenceContext
    EntityManager entityManager;

	@Override
	public List<Article> findTop10ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(String title,
			String content) {
		Query query = entityManager.createNativeQuery("SELECT * FROM article a WHERE LOWER(a.title) LIKE %ignorecase% OR UPPER(a.content) LIKE %IGNORECASE%", Article.class);
		query.setFirstResult(1);
		query.setMaxResults(10);	
		List<Article> articles = query.getResultList();
        return articles;
	}

}

