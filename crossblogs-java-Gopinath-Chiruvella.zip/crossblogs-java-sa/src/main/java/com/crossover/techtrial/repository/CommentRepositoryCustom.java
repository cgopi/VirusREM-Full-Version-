package com.crossover.techtrial.repository;

import java.util.List;

import com.crossover.techtrial.model.Comment;

public interface CommentRepositoryCustom {

	  List<Comment> findByArticleIdOrderByDate(Long articleId);
}
