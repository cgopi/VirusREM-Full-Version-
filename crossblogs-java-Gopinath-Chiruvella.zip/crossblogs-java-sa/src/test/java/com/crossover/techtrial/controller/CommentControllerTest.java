package com.crossover.techtrial.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.crossover.techtrial.model.Article;
import com.crossover.techtrial.model.Comment;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CommentControllerTest {

  @Autowired
  private TestRestTemplate template;
  
  @Autowired
  private CommentController commentController;

  @Before
  public void setup() throws Exception {

  }

  @Test
  public void testCommentShouldBeCreated() throws Exception {
    HttpEntity<Object> comment = getHttpEntity(
        "{\"email\": \"user1@gmail.com\", \"date\": \"05/13/2018\", \"message\": \"This is a comment\" }");
    ResponseEntity<Comment> resultAsset = template.postForEntity("/comments", comment,
        Comment.class);
    Assert.assertNotNull(resultAsset.getBody().getId());
  }

  private HttpEntity<Object> getHttpEntity(Object body) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return new HttpEntity<Object>(body, headers);
  }
  
  @Test
  public void testCreateComment() {
	  Comment comment = new Comment();
	  Article article = new Article();
	  article.setEmail("user4@gmail.com");
	  article.setDate(LocalDateTime.now());
	  article.setId(2L);
	  article.setPublished(true);
	  article.setContent("My content2");
	  article.setTitle("My Article");
	  
	  comment.setArticle(article);
	  comment.setDate(LocalDateTime.now());
	  comment.setEmail("testuser@gmail.com");
	  comment.setId(3L);
	  comment.setMessage("My message");
      ResponseEntity<Comment> entity = commentController.createComment(1L, comment);
      Assert.assertEquals(entity.getStatusCode(), HttpStatus.OK);
  }
  
  @Test
  public void testGetComments() {
	  ResponseEntity<List<Comment>> entity = commentController.getComments(2L);
	  Assert.assertEquals(entity.getStatusCode(), HttpStatus.OK);
  }
  
}