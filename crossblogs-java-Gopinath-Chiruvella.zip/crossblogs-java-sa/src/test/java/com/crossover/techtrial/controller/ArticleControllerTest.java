package com.crossover.techtrial.controller;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.crossover.techtrial.model.Article;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Transactional
@Rollback
public class ArticleControllerTest {

  @Autowired
  private TestRestTemplate template;
  @Autowired 
  private ArticleController articleController;
  @PersistenceContext 
  private EntityManager em;

  @Before
  public void setup() throws Exception {

  }
  
  @Test
  public void testArticleShouldBeCreated() throws Exception {
    HttpEntity<Object> article = getHttpEntity(
        "{\"email\": \"user1@gmail.com\", \"title\": \"hello\" }");
    ResponseEntity<Article> resultAsset = template.postForEntity("/articles", article,
        Article.class);
    Assert.assertNotNull(resultAsset.getBody().getId());
  }

  private HttpEntity<Object> getHttpEntity(Object body) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return new HttpEntity<Object>(body, headers);
  }
  
  @Test
  public void testGetArticleById_Success() {
      ResponseEntity<Article> entity = articleController.getArticleById(1L);
      Assert.assertEquals(entity.getStatusCode(), HttpStatus.OK);
  }
  
  @Test
  public void testGetArticleById_Failure() {
      ResponseEntity<Article> entity = articleController.getArticleById(1L);
      Assert.assertEquals(entity.getStatusCode(), HttpStatus.NOT_FOUND);
  }

  @Test
  public void testCreateArticle() {
	  Article article = new Article();
	  article.setEmail("user2@gmail.com");
	  article.setDate(LocalDateTime.now());
	  article.setId(1L);
	  article.setPublished(true);
	  article.setContent("My content");
	  article.setTitle("Article1");
	  ResponseEntity<Article> entity = articleController.createArticle(article);
	  Assert.assertEquals(entity.getStatusCode(), HttpStatus.CREATED);
  }
  
  @Test
  public void testUpdateArticle() {
	  ResponseEntity<Article> entity = articleController.getArticleById(1L);
	  Article article = entity.getBody();
	  article.setEmail("user3@gmail.com");
	  article.setContent("My content1");
	  ResponseEntity<Article> entity1 = articleController.updateArticle(1L, article);
	  Assert.assertEquals(entity1.getStatusCode(), HttpStatus.OK);
  }
  
  @Test
  public void testDeleteArticleById() {
	  ResponseEntity<Article> entity = articleController.deleteArticleById(1L);
	  Assert.assertEquals(entity.getStatusCode(), HttpStatus.OK);
  }
  
  @Test
  public void testSearchArticles() {
	  ResponseEntity<List<Article>> entity = articleController.searchArticles("Article1");
	  Assert.assertEquals(entity.getStatusCode(), HttpStatus.OK);
  }
  
}