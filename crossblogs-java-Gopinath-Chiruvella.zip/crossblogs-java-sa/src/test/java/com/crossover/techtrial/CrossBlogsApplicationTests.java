package com.crossover.techtrial;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.crossover.techtrial.model.Article;
import com.crossover.techtrial.model.Comment;
import com.crossover.techtrial.repository.ArticleRepository;
import com.crossover.techtrial.repository.CommentRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = CrossBlogsApplication.class)
@AutoConfigureMockMvc
public class CrossBlogsApplicationTests {

    @Autowired
    private ArticleRepository articleRepository;
    
    @Autowired
    private CommentRepository commentRepository;

	@Test
	public void contextLoads() {
	}

	@Test
	public void testFindTop10ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase_Success() {
		List<Article> articles = articleRepository.findTop10ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase("Article1", "My content");
		Long id = null;
		String email = null;
		Boolean published = null;

		if (articles != null) {
			id = articles.get(0).getId();
			email = articles.get(0).getEmail();
			published = articles.get(0).getPublished();
		}
		
		Assert.assertNotNull(articles);
		Assert.assertEquals(email, "user2@gmail.com");
		Assert.assertEquals(id, (Long)1L);
		Assert.assertEquals(published, (Boolean)true);
	}
	
	@Test
	public void testFindTop10ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase_Null() {
		List<Article> articles = articleRepository.findTop10ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase("", "");
		Long id = null;
		String email = null;
		Boolean published = null;

		Assert.assertNull(articles);
		Assert.assertEquals(email, null);
		Assert.assertEquals(id, null);
		Assert.assertEquals(published, null);
	}
	
	@Test
	public void testFindByArticleIdOrderByDate_Success() {
		List<Comment> comments = commentRepository.findByArticleIdOrderByDate(2L);
		Long id = null;
		String email = null;
		String message = null;
		
		if (comments != null) {
			id = comments.get(0).getId();
			email = comments.get(0).getEmail();
			message = comments.get(0).getMessage();
		}
		
		Assert.assertNotNull(comments);
		Assert.assertEquals(email, "testuser@gmail.com");
		Assert.assertEquals(id, (Long)3L);
		Assert.assertEquals(message, "My message");
	}
	
	@Test
	public void testFindByArticleIdOrderByDate_Null() {
		List<Comment> comments = commentRepository.findByArticleIdOrderByDate(0L);
		Long id = null;
		String email = null;
		String message = null;
		
		Assert.assertNull(comments);
		Assert.assertEquals(email, null);
		Assert.assertEquals(id, null);
		Assert.assertEquals(message, null);
	}
	
}